<?php

declare(strict_types=1);

namespace Mellowmessage\Doctors\Controller;


//TYPO3 CORE
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use TYPO3\CMS\Core\Utility\GeneralUtility;

/**
 * This file is part of the "Doctors" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

 /**
 * SymptomController
 */
class SymptomController extends ActionController
{
    
}