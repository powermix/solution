<?php
defined('TYPO3') or die('Access denied.');

//TYPO3 CORE
use TYPO3\CMS\Extbase\Utility\ExtensionUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

//Doctors sitepackage
use Mellowmessage\Doctors\Controller\DoctorController;
use Mellowmessage\Doctors\Controller\SymptomController;

/***************
 * Add default RTE configuration
 */
$GLOBALS['TYPO3_CONF_VARS']['RTE']['Presets']['doctors'] = 'EXT:doctors/Configuration/RTE/Default.yaml';

/***************
 * PageTS
 */
ExtensionManagementUtility::addPageTSConfig('<INCLUDE_TYPOSCRIPT: source="FILE:EXT:doctors/Configuration/TsConfig/Page/All.tsconfig">');



/***************
 * Frontend Plugin Doctors
 */
(static function() {
    ExtensionUtility::configurePlugin(
        'Doctors',
        'PluginFrontend',
        [
           DoctorController::class => 'list'
        ],
        // non-cacheable actions
        [
            DoctorController::class => ''
        ]
    );
})();