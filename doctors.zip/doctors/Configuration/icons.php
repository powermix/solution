<?php


// Icon API TYPO3
use TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider;
use TYPO3\CMS\Core\Imaging\IconProvider\BitmapIconProvider;

return [
    'doctors-pluginfrontend' => [
        'provider' => SvgIconProvider::class,
        //Source of svg
        'source' => 'EXT:doctors/Resources/Public/Icons/doctor.svg',
    ],
];
