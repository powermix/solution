
const form = document.getElementById('search-from');


//Init Symptoms MultiSelect
// DOCS & Options
new SlimSelect({
    select: '#symptoms',
    placeholder: 'Please choose one or more Symptom to help you out.', 
})


// disable / enable Button
document.getElementById('symptoms').addEventListener("change", function(){
    if (this.value != '') {
        document.getElementById('submit').disabled = false;
    }else{
        document.getElementById('submit').disabled = true;
    }
});
