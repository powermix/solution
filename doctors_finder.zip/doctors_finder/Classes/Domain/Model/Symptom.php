<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Domain\Model;


/**
 * This file is part of the "Doctors Finder" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

/**
 * Symptom
 */
class Symptom extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * symptom
     *
     * @var string
     */
    protected $symptom = '';

    /**
     * Returns the symptom
     *
     * @return string
     */
    public function getSymptom()
    {
        return $this->symptom;
    }

    /**
     * Sets the symptom
     *
     * @param string $symptom
     * @return void
     */
    public function setSymptom(string $symptom)
    {
        $this->symptom = $symptom;
    }
}
