<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Domain\Model;


/**
 * This file is part of the "Doctors Finder" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

/**
 * Doctor
 */
class Doctor extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * prefix
     *
     * @var int
     */
    protected $prefix = 0;

    /**
     * firstname
     *
     * @var string
     */
    protected $firstname = '';

    /**
     * lastname
     *
     * @var string
     */
    protected $lastname = '';

    /**
     * phone
     *
     * @var string
     */
    protected $phone = '';

    /**
     * specialfield
     *
     * @var string
     */
    protected $specialfield = '';

    /**
     * symptoms
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\HS\DoctorsFinder\Domain\Model\Symptom>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $symptoms = null;

    /**
     * __construct
     */
    public function __construct()
    {

        // Do not remove the next line: It would break the functionality
        $this->initializeObject();
    }

    /**
     * Initializes all ObjectStorage properties when model is reconstructed from DB (where __construct is not called)
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    public function initializeObject()
    {
        $this->symptoms = $this->symptoms ?: new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the prefix
     *
     * @return int
     */
    public function getPrefix()
    {
        return $this->prefix;
    }

    /**
     * Sets the prefix
     *
     * @param int $prefix
     * @return void
     */
    public function setPrefix(int $prefix)
    {
        $this->prefix = $prefix;
    }

    /**
     * Returns the firstname
     *
     * @return string
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * Sets the firstname
     *
     * @param string $firstname
     * @return void
     */
    public function setFirstname(string $firstname)
    {
        $this->firstname = $firstname;
    }

    /**
     * Returns the lastname
     *
     * @return string
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * Sets the lastname
     *
     * @param string $lastname
     * @return void
     */
    public function setLastname(string $lastname)
    {
        $this->lastname = $lastname;
    }

    /**
     * Returns the phone
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Sets the phone
     *
     * @param string $phone
     * @return void
     */
    public function setPhone(string $phone)
    {
        $this->phone = $phone;
    }

    /**
     * Returns the specialfield
     *
     * @return string
     */
    public function getSpecialfield()
    {
        return $this->specialfield;
    }

    /**
     * Sets the specialfield
     *
     * @param string $specialfield
     * @return void
     */
    public function setSpecialfield(string $specialfield)
    {
        $this->specialfield = $specialfield;
    }

    /**
     * Adds a Symptom
     *
     * @param \HS\DoctorsFinder\Domain\Model\Symptom $symptom
     * @return void
     */
    public function addSymptom(\HS\DoctorsFinder\Domain\Model\Symptom $symptom)
    {
        $this->symptoms->attach($symptom);
    }

    /**
     * Removes a Symptom
     *
     * @param \HS\DoctorsFinder\Domain\Model\Symptom $symptomToRemove The Symptom to be removed
     * @return void
     */
    public function removeSymptom(\HS\DoctorsFinder\Domain\Model\Symptom $symptomToRemove)
    {
        $this->symptoms->detach($symptomToRemove);
    }

    /**
     * Returns the symptoms
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\HS\DoctorsFinder\Domain\Model\Symptom>
     */
    public function getSymptoms()
    {
        return $this->symptoms;
    }

    /**
     * Sets the symptoms
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\HS\DoctorsFinder\Domain\Model\Symptom> $symptoms
     * @return void
     */
    public function setSymptoms(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $symptoms)
    {
        $this->symptoms = $symptoms;
    }
}
