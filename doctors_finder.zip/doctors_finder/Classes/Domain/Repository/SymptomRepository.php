<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Domain\Repository;


//TYPO3 CORE
use Doctrine\DBAL\Connection;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;  
use TYPO3\CMS\Extbase\Persistence\QueryInterface;

/**
 * This file is part of the "Doctors Finder" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

/**
 * The repository for Symptom
 */
class SymptomRepository extends Repository
{
    //Get all Symptoms UID and Symptom
    public function getSymptoms(){
        $table = "tx_doctorsfinder_domain_model_symptom";
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable($table);
        $statement = $queryBuilder
            ->select('uid','symptom')
            ->from($table)
            ->execute()
            ->fetchAll();
        return $statement;
    }
    
    /**
     * Find Symptoms by a given uid
     *
     * @param array $idList list of id s
     */
    public function getSymptomsByUids(array $idList)
    {
       
        if (empty($idList)) {
            throw new \InvalidArgumentException('The given id list is empty.', 1484823597);
        }
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('tx_doctorsfinder_domain_model_symptom');
        $rows = $queryBuilder
            ->select('uid', 'symptom')
            ->from('tx_doctorsfinder_domain_model_symptom')
            ->where(
                $queryBuilder->expr()->in('uid', $queryBuilder->createNamedParameter($idList, Connection::PARAM_INT_ARRAY))
            )
            ->execute()
            ->fetchAll();
        return $rows;
        
    }
}