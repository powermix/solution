<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Domain\Repository;

//TYPO3 CORE 
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;  
use TYPO3\CMS\Extbase\Persistence\QueryInterface;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * This file is part of the "Doctors Finder" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

/**
 * The repository for Doctors
 */
class DoctorRepository extends Repository
{
    //Get all Doctors assigned to each Symptom 
    public function getDoctors($uid){
        $table = "tx_doctorsfinder_domain_model_doctor";
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable($table);
        $statement = $queryBuilder
            ->select('uid','prefix','firstname','lastname','phone','specialfield','symptoms')
            ->from($table)
            ->where($queryBuilder->expr()->inSet('symptoms', $queryBuilder->createNamedParameter($uid, \PDO::PARAM_INT)))
            ->execute()
            ->fetchAll();
        return $statement;
    }
}
