<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Controller;


/**
 * This file is part of the "Doctors Finder" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

/**
 * SymptomController
 */
class SymptomController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * action list
     *
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function listAction(): \Psr\Http\Message\ResponseInterface
    {
        $symptoms = $this->symptomRepository->findAll();
        $this->view->assign('symptoms', $symptoms);
        return $this->htmlResponse();
    }
}
