<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Controller;

//TYPO3 CORE
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use Psr\Http\Message\ResponseInterface;

use HS\DoctorsFinder\Domain\Repository\DoctorRepository;
use HS\DoctorsFinder\Domain\Repository\SymptomRepository;



/**
 * This file is part of the "Doctors Finder" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 Hamada Saidi <hamada.saidi@gmx.de>
 */

/**
 * DoctorController
 */
class DoctorController extends ActionController
{

    /*=======Variables============*/
    /**
     * doctorRepository
     *
     * @var DoctorRepository
     */
    protected $doctorRepository;

    /**
     * symptomRepository
     *
     * @var SymptomRepository
     */
    protected $symptomRepository;

    /*=======Constructor============*/
    public function __construct(
        DoctorRepository $doctorRepository,
        SymptomRepository $symptomRepository
        )
    {
        //injecting both Repositories
        $this->doctorRepository = $doctorRepository;
        $this->symptomRepository = $symptomRepository;
    }

    /*=======Actions============*/
    /**
     * action index
     *
     * @return ResponseInterface
     */
    public function indexAction(): ResponseInterface
    {
        $symptoms = $this->symptomRepository->getSymptoms();
        $this->view->assign('symptoms', $symptoms);
        return $this->htmlResponse();
    }
    
    /**
     * action list
     *
     * @return ResponseInterface
     */
    public function listAction(): ResponseInterface
    {
        //array to hold doctors 
        $doctors = [];
        //array for end searching result
        $modifed = [];
        //getting all symptoms for searching possibility in listing view
        $symptoms = $this->symptomRepository->findAll();

        //check if there is Post request
        if (isset($_POST)) {
            $chosenSymptoms = $_POST['tx_doctorsfinder_frontendplugin']['symptoms'];
            //Iterating throw Doctors and return each doctor can heal the assigned Symptom
            foreach ($chosenSymptoms as $symptom ) {
                // get doctor by Symptoms
                $doctors[] = $this->doctorRepository->getDoctors($symptom);   
                             
            }
            // merging all doctors in one big array
            // avoiding array merge in for loop performance killer, using spread instead.
            $merged = array_merge(...$doctors);
            
            //get Symptoms by UID and append it to doctor 
            foreach ($merged as $doctor) {
                if (is_string($doctor['symptoms'])) {
                    $docSymptoms = GeneralUtility::trimExplode(',', $doctor['symptoms']);
                }
                if (!empty($docSymptoms)) {
                    $doctor['specialties'] = $this->symptomRepository->getSymptomsByUids($docSymptoms);
                }
                $modifed[] = $doctor;
            }
            

            // assign views
            $this->view->assign('doctors',$modifed);
            $this->view->assign('symptoms', $symptoms);
            return $this->htmlResponse();

        } else  {
            $this->view->assign('sorry','sorry we could not find a specialized doctor, please try later again.');
            return $this->htmlResponse();
        }
        
    }
}
