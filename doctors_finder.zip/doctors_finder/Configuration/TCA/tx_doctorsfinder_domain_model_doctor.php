<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor',
        'label' => 'prefix',
        'label_alt' => 'firstname,lastname',
        'label_alt_force' => '1',
        'sortby' => 'uid',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'versioningWS' => true,
        'languageField' => 'sys_language_uid',
        'transOrigPointerField' => 'l10n_parent',
        'transOrigDiffSourceField' => 'l10n_diffsource',
        'delete' => 'deleted',
        'enablecolumns' => [
            'disabled' => 'hidden',
            'starttime' => 'starttime',
            'endtime' => 'endtime',
        ],
        'searchFields' => 'firstname,lastname,phone,specialfield',
        'iconfile' => 'EXT:doctors_finder/Resources/Public/Icons/tx_doctorsfinder_domain_model_doctor.gif'
    ],
    'types' => [
        '1' => ['showitem' => 'prefix, firstname, lastname, phone, specialfield, symptoms, --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:language, sys_language_uid, l10n_parent, l10n_diffsource, --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:access, hidden, starttime, endtime'],
    ],
    'columns' => [
        'sys_language_uid' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.language',
            'config' => [
                'type' => 'language',
            ],
        ],
        'l10n_parent' => [
            'displayCond' => 'FIELD:sys_language_uid:>:0',
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.l18n_parent',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'default' => 0,
                'items' => [
                    ['', 0],
                ],
                'foreign_table' => 'tx_doctorsfinder_domain_model_doctor',
                'foreign_table_where' => 'AND {#tx_doctorsfinder_domain_model_doctor}.{#pid}=###CURRENT_PID### AND {#tx_doctorsfinder_domain_model_doctor}.{#sys_language_uid} IN (-1,0)',
            ],
        ],
        'l10n_diffsource' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.visible',
            'config' => [
                'type' => 'check',
                'renderType' => 'checkboxToggle',
                'items' => [
                    [
                        0 => '',
                        1 => '',
                        'invertStateDisplay' => true
                    ]
                ],
            ],
        ],
        'starttime' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.starttime',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'eval' => 'datetime,int',
                'default' => 0,
                'behaviour' => [
                    'allowLanguageSynchronization' => true
                ]
            ],
        ],
        'endtime' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.endtime',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'eval' => 'datetime,int',
                'default' => 0,
                'range' => [
                    'upper' => mktime(0, 0, 0, 1, 1, 2038)
                ],
                'behaviour' => [
                    'allowLanguageSynchronization' => true
                ]
            ],
        ],

        'prefix' => [
            'exclude' => true,
            'label' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor.prefix',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['Title', 0],
                    ['Dr.', 1],
                    ['Pr. Dr', 2],
                    ['Frau', 3],
                    ['Herr', 4],
                ],
                'size' => 1,
                'maxitems' => 1,
                'eval' => ''
            ],
        ],
        'firstname' => [
            'exclude' => true,
            'label' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor.firstname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim',
                'default' => ''
            ],
        ],
        'lastname' => [
            'exclude' => true,
            'label' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor.lastname',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim',
                'default' => ''
            ],
        ],
        'phone' => [
            'exclude' => true,
            'label' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor.phone',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim',
                'default' => ''
            ],
        ],
        'specialfield' => [
            'exclude' => true,
            'label' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor.specialfield',
            'config' => [
                'type' => 'input',
                'size' => 30,
                'eval' => 'trim',
                'default' => ''
            ],
        ],
        'symptoms' => [
            'exclude' => true,
            'label' => 'LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctorsfinder_domain_model_doctor.symptoms',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectMultipleSideBySide',
                'foreign_table' => 'tx_doctorsfinder_domain_model_symptom',
                'default' => 0,
                'size' => 10,
                'autoSizeMax' => 30,
                'maxitems' => 9999,
                'multiple' => 0,
                'fieldControl' => [
                    'editPopup' => [
                        'disabled' => false,
                    ],
                    'addRecord' => [
                        'disabled' => false,
                    ],
                    'listModule' => [
                        'disabled' => true,
                    ],
                ],
            ],

        ],
    
    ],
];
