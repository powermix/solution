<?php

return [
    'doctors_finder-plugin-frontendplugin' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:doctors_finder/Resources/Public/Icons/user_plugin_frontendplugin.svg'
    ],
];
