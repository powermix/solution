<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Doctors Finder',
    'description' => 'A frontend plugin to find doctor by symptoms ',
    'category' => 'plugin',
    'author' => 'Hamada Saidi',
    'author_email' => 'hamada.saidi@gmx.de',
    'state' => 'alpha',
    'clearCacheOnLoad' => 0,
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '11.5.0-11.5.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
