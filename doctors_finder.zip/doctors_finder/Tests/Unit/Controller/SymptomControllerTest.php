<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Tests\Unit\Controller;

use PHPUnit\Framework\MockObject\MockObject;
use TYPO3\TestingFramework\Core\AccessibleObjectInterface;
use TYPO3\TestingFramework\Core\Unit\UnitTestCase;
use TYPO3Fluid\Fluid\View\ViewInterface;

/**
 * Test case
 *
 * @author Hamada Saidi <hamada.saidi@gmx.de>
 */
class SymptomControllerTest extends UnitTestCase
{
    /**
     * @var \HS\DoctorsFinder\Controller\SymptomController|MockObject|AccessibleObjectInterface
     */
    protected $subject;

    protected function setUp(): void
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder($this->buildAccessibleProxy(\HS\DoctorsFinder\Controller\SymptomController::class))
            ->onlyMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllSymptomsFromRepositoryAndAssignsThemToView(): void
    {
        $allSymptoms = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $symptomRepository = $this->getMockBuilder(\::class)
            ->onlyMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $symptomRepository->expects(self::once())->method('findAll')->will(self::returnValue($allSymptoms));
        $this->subject->_set('symptomRepository', $symptomRepository);

        $view = $this->getMockBuilder(ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('symptoms', $allSymptoms);
        $this->subject->_set('view', $view);

        $this->subject->listAction();
    }
}
