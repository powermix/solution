<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Tests\Unit\Domain\Model;

use PHPUnit\Framework\MockObject\MockObject;
use TYPO3\TestingFramework\Core\AccessibleObjectInterface;
use TYPO3\TestingFramework\Core\Unit\UnitTestCase;

/**
 * Test case
 *
 * @author Hamada Saidi <hamada.saidi@gmx.de>
 */
class SymptomTest extends UnitTestCase
{
    /**
     * @var \HS\DoctorsFinder\Domain\Model\Symptom|MockObject|AccessibleObjectInterface
     */
    protected $subject;

    protected function setUp(): void
    {
        parent::setUp();

        $this->subject = $this->getAccessibleMock(
            \HS\DoctorsFinder\Domain\Model\Symptom::class,
            ['dummy']
        );
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getSymptomReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getSymptom()
        );
    }

    /**
     * @test
     */
    public function setSymptomForStringSetsSymptom(): void
    {
        $this->subject->setSymptom('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('symptom'));
    }
}
