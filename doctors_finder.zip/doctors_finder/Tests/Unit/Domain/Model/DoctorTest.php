<?php

declare(strict_types=1);

namespace HS\DoctorsFinder\Tests\Unit\Domain\Model;

use PHPUnit\Framework\MockObject\MockObject;
use TYPO3\TestingFramework\Core\AccessibleObjectInterface;
use TYPO3\TestingFramework\Core\Unit\UnitTestCase;

/**
 * Test case
 *
 * @author Hamada Saidi <hamada.saidi@gmx.de>
 */
class DoctorTest extends UnitTestCase
{
    /**
     * @var \HS\DoctorsFinder\Domain\Model\Doctor|MockObject|AccessibleObjectInterface
     */
    protected $subject;

    protected function setUp(): void
    {
        parent::setUp();

        $this->subject = $this->getAccessibleMock(
            \HS\DoctorsFinder\Domain\Model\Doctor::class,
            ['dummy']
        );
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getPrefixReturnsInitialValueForInt(): void
    {
        self::assertSame(
            0,
            $this->subject->getPrefix()
        );
    }

    /**
     * @test
     */
    public function setPrefixForIntSetsPrefix(): void
    {
        $this->subject->setPrefix(12);

        self::assertEquals(12, $this->subject->_get('prefix'));
    }

    /**
     * @test
     */
    public function getFirstnameReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getFirstname()
        );
    }

    /**
     * @test
     */
    public function setFirstnameForStringSetsFirstname(): void
    {
        $this->subject->setFirstname('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('firstname'));
    }

    /**
     * @test
     */
    public function getLastnameReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getLastname()
        );
    }

    /**
     * @test
     */
    public function setLastnameForStringSetsLastname(): void
    {
        $this->subject->setLastname('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('lastname'));
    }

    /**
     * @test
     */
    public function getPhoneReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getPhone()
        );
    }

    /**
     * @test
     */
    public function setPhoneForStringSetsPhone(): void
    {
        $this->subject->setPhone('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('phone'));
    }

    /**
     * @test
     */
    public function getSpecialfieldReturnsInitialValueForString(): void
    {
        self::assertSame(
            '',
            $this->subject->getSpecialfield()
        );
    }

    /**
     * @test
     */
    public function setSpecialfieldForStringSetsSpecialfield(): void
    {
        $this->subject->setSpecialfield('Conceived at T3CON10');

        self::assertEquals('Conceived at T3CON10', $this->subject->_get('specialfield'));
    }

    /**
     * @test
     */
    public function getSymptomsReturnsInitialValueForSymptom(): void
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getSymptoms()
        );
    }

    /**
     * @test
     */
    public function setSymptomsForObjectStorageContainingSymptomSetsSymptoms(): void
    {
        $symptom = new \HS\DoctorsFinder\Domain\Model\Symptom();
        $objectStorageHoldingExactlyOneSymptoms = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneSymptoms->attach($symptom);
        $this->subject->setSymptoms($objectStorageHoldingExactlyOneSymptoms);

        self::assertEquals($objectStorageHoldingExactlyOneSymptoms, $this->subject->_get('symptoms'));
    }

    /**
     * @test
     */
    public function addSymptomToObjectStorageHoldingSymptoms(): void
    {
        $symptom = new \HS\DoctorsFinder\Domain\Model\Symptom();
        $symptomsObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->onlyMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $symptomsObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($symptom));
        $this->subject->_set('symptoms', $symptomsObjectStorageMock);

        $this->subject->addSymptom($symptom);
    }

    /**
     * @test
     */
    public function removeSymptomFromObjectStorageHoldingSymptoms(): void
    {
        $symptom = new \HS\DoctorsFinder\Domain\Model\Symptom();
        $symptomsObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->onlyMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $symptomsObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($symptom));
        $this->subject->_set('symptoms', $symptomsObjectStorageMock);

        $this->subject->removeSymptom($symptom);
    }
}
