<?php
defined('TYPO3') || die();

(static function() {
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
        'DoctorsFinder',
        'Frontendplugin',
        [
            \HS\DoctorsFinder\Controller\DoctorController::class => 'index,list'
        ],
        // non-cacheable actions
        [
            \HS\DoctorsFinder\Controller\DoctorController::class => '',
            \HS\DoctorsFinder\Controller\SymptomController::class => ''
        ]
    );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    frontendplugin {
                        iconIdentifier = doctors_finder-plugin-frontendplugin
                        title = LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctors_finder_frontendplugin.name
                        description = LLL:EXT:doctors_finder/Resources/Private/Language/locallang_db.xlf:tx_doctors_finder_frontendplugin.description
                        tt_content_defValues {
                            CType = list
                            list_type = doctorsfinder_frontendplugin
                        }
                    }
                }
                show = *
            }
       }'
    );
})();
