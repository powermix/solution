CREATE TABLE tx_doctorsfinder_domain_model_doctor (
	prefix int(11) DEFAULT '0' NOT NULL,
	firstname varchar(255) NOT NULL DEFAULT '',
	lastname varchar(255) NOT NULL DEFAULT '',
	phone varchar(255) NOT NULL DEFAULT '',
	specialfield varchar(255) NOT NULL DEFAULT '',
	symptoms text NOT NULL
);

CREATE TABLE tx_doctorsfinder_domain_model_symptom (
	symptom varchar(255) NOT NULL DEFAULT ''
);
