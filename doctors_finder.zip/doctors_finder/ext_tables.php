<?php
defined('TYPO3') || die();

(static function() {
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_doctorsfinder_domain_model_doctor', 'EXT:doctors_finder/Resources/Private/Language/locallang_csh_tx_doctorsfinder_domain_model_doctor.xlf');
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_doctorsfinder_domain_model_doctor');

    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_doctorsfinder_domain_model_symptom', 'EXT:doctors_finder/Resources/Private/Language/locallang_csh_tx_doctorsfinder_domain_model_symptom.xlf');
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_doctorsfinder_domain_model_symptom');
})();
